﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Event_Calendar_In_AngularJS.Startup))]
namespace Event_Calendar_In_AngularJS
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
